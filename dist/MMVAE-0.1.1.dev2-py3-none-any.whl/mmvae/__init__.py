import warnings
warnings.filterwarnings('ignore', '.*Sparse CSR tensor support is in beta state.*')